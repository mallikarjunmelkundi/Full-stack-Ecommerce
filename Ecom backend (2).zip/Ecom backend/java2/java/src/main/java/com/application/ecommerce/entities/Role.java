package com.application.ecommerce.entities;

public enum Role {
USER,
ADMIN
}
