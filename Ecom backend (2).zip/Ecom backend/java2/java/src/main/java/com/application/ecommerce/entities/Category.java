package com.application.ecommerce.entities;

public enum Category {
	MEN,
    WOMEN,
    BABY,
    TOY,
    MOBILE,
    LAPTOP
}
